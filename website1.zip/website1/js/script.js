function showTimetable() {
    var teacher = document.getElementById("select-teacher").value;
    var day = document.getElementById("select-day").value;
    var schedule = document.querySelector('input[name="schedule"]:checked').value;
  
    if (teacher && day && schedule) {
      var timetable = document.getElementById("timetable");
      timetable.innerHTML = "";
  
      var heading = document.createElement("h2");
      heading.innerText = "Timetable for " + teacher + " on " + day + " (" + schedule + ")";
      timetable.appendChild(heading);
  
      var table = document.createElement("table");
  
      var thead = document.createElement("thead");
      var tr = document.createElement("tr");
  
      var th = document.createElement("th");
      th.innerText = "Time/Period";
      tr.appendChild(th);
  
      for (var i = 1; i <= 6; i++) {
        var th = document.createElement("th");
        th.innerText = "Period " + i;
        tr.appendChild(th);
      }
  
      thead.appendChild(tr);
      table.appendChild(thead);
  
      var tbody = document.createElement("tbody");
    }
}

  