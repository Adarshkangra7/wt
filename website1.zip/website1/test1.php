<?php
$file = "class.txt";
$content = file_get_contents($file);
$formatted_content = '<pre>' . nl2br(htmlspecialchars($content)) . '</pre>';
echo $formatted_content;
?>

<html>
    <body style="">

    </body>
</html>