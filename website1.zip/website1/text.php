<?php
$file = "teacher.txt";
$content = file_get_contents($file);
$formatted_content = '<pre>' . nl2br(htmlspecialchars($content)) . '</pre>';
echo $formatted_content;
?>

<html>
    <body style="background: #7F7FD5;  /* fallback for old browsers */
background: -webkit-linear-gradient(to left, #91EAE4, #86A8E7, #7F7FD5);  /* Chrome 10-25, Safari 5.1-6 */
background: linear-gradient(to left, #91EAE4, #86A8E7, #7F7FD5); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
">

    </body>
</html>