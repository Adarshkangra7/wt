-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 12, 2023 at 05:13 PM
-- Server version: 8.0.29
-- PHP Version: 8.0.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `timetable`
--

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `course_code` varchar(7) NOT NULL,
  `course_name` varchar(100) NOT NULL,
  `course_type` varchar(1) NOT NULL,
  `course_hours` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`course_code`, `course_name`, `course_type`, `course_hours`) VALUES
('BCA121', 'PROFESSIONAL ENGLISH', 'C', 3),
('BCA131', 'FOUNDATIONAL MATHEMATICS', 'C', 3),
('BCA132', 'STATISTICS-I FOR BCA', 'C', 3),
('BCA133', 'DIGITAL COMPUTER FUNDAMENTALS', 'C', 4),
('BCA134', 'INTRODUCTION TO PROGRAMMING USING C', 'C', 4),
('BCA151', 'DIGITAL COMPUTER FUNDAMENTALS LAB', 'L', 2),
('BCA152', 'C PROGRAMMING LAB', 'L', 4),
('BCA171', 'PYTHON PROGRAMMING-I', 'L', 4),
('BCA212', 'STATISTICS TOOLS LAB', 'L', 2),
('BCA221', 'COMMUNICATIVE ENGLISH', 'C', 3),
('BCA231', 'BASIC DISCRETE MATHEMATICS', 'C', 3),
('BCA232', 'STATISTICS-II FOR BCA', 'C', 3),
('BCA233', 'OPERATING SYSTEMS', 'C', 4),
('BCA234', 'DATA STRUCTURES', 'C', 4),
('BCA251', 'OPERATING SYSTEM LAB', 'L', 4),
('BCA252', 'DATA STRUCTURES LAB', 'L', 4),
('BCA312', 'ACCOUNTING TOOLS LAB', 'L', 2),
('BCA331', 'INTRODUCTION TO NUMBER THEORY AND ALGEBRA', 'C', 3),
('BCA332', 'FINANCIAL ACCOUNTING', 'C', 3),
('BCA333', 'OBJECT ORIENTED PROGRAMMING USING JAVA', 'C', 4),
('BCA334', 'DATABASE MANAGEMENT SYSTEM', 'C', 4),
('BCA351', 'JAVA PROGRAMMING LAB', 'L', 4),
('BCA352', 'DBMS LAB', 'C', 2),
('BCA352L', 'DBMS LAB', 'L', 2),
('BCA361A', 'GERMAN', 'E', 4),
('BCA361B', 'FRENCH', 'E', 4),
('BCA431', 'GRAPH THEORY', 'C', 3),
('BCA432', 'FINANCIAL MANAGEMENT', 'C', 3),
('BCA433', 'DESIGN AND ANALYSIS OF ALGORITHMS', 'C', 4),
('BCA434', 'SOFTWARE ENGINEERING', 'C', 4),
('BCA435', 'WEB TECHNOLOGY', 'C', 4),
('BCA451', '.NET LAB', 'L', 4),
('BCA481', 'DBMS PROJECT', 'L', 6),
('BCA531', 'PYTHON PROGRAMMING', 'C', 4),
('BCA532', 'COMPUTER NETWORKS', 'C', 4),
('BCA541A', 'MOBILE APPLICATIONS', 'E', 4),
('BCA541B', 'GRAPHICS AND ANIMATION', 'E', 4),
('BCA541C', 'BUSINESS INTELLIGENCE', 'E', 4),
('BCA541D', 'MICROPROCESSOR AND ALP', 'E', 4),
('BCA541E', 'DIGITAL IMAGE PROCESSING', 'E', 4),
('BCA542A', 'MULTIMEDIA APPLICATIONS', 'E', 4),
('BCA542B', 'OOAD USING UML', 'E', 4),
('BCA542C', 'CYBER SECURITY', 'E', 4),
('BCA542D', 'COMPUTER ARCHITECTURE', 'E', 4),
('BCA542E', 'SYSTEM SOFTWARE', 'E', 4),
('BCA551', 'PYTHON PROGRAMMING LAB', 'L', 4),
('BCA552A', 'MOBILE APPLICATIONS LAB', 'X', 4),
('BCA552B', 'GRAPHICS AND ANIMATION LAB', 'X', 4),
('BCA552C', 'BUSINESS INTELLIGENCE LAB', 'X', 4),
('BCA552D', 'MICROPROCESSOR AND ALP LAB', 'X', 4),
('BCA552E', 'DIGITAL IMAGE PROCESSING LAB', 'X', 4),
('BCA581', 'PROJECT-I', 'C', 4),
('BCA671', 'MACHINE LEARNING', 'C', 6),
('BCA672A', 'CLOUD COMPUTING', 'E', 6),
('BCA672B', 'UI/UX DESIGN', 'E', 6),
('BCA672C', 'SOFTWARE TESTING', 'E', 6),
('BCA672D', 'INTERNET OF THINGS', 'E', 6),
('BCA672E', 'LINUX ADMINISTRATION', 'E', 6),
('BCA681', 'MAJOR PROJECT', 'C', 16);

-- --------------------------------------------------------

--
-- Table structure for table `teachers`
--

CREATE TABLE `teachers` (
  `teacher_id` int NOT NULL,
  `teacher_name` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `teachers`
--

INSERT INTO `teachers` (`teacher_id`, `teacher_name`) VALUES
(0, ''),
(1, 'DAN'),
(2, 'PUN'),
(3, 'BVD'),
(4, 'SK'),
(5, 'PR'),
(6, 'AA'),
(7, 'CHR'),
(8, 'DEV'),
(9, 'JIJU'),
(10, 'KR'),
(11, 'KNS'),
(12, 'SV'),
(13, 'TB'),
(14, 'MAH'),
(15, 'PA'),
(16, 'XX'),
(17, 'AN'),
(18, 'HB'),
(19, 'SRI'),
(20, 'ZZ'),
(21, 'BE'),
(22, 'JAYA'),
(23, 'YY'),
(24, 'MP'),
(25, 'VV'),
(26, 'BB'),
(27, 'RU/DS'),
(28, 'RM/NR'),
(29, 'VB'),
(30, 'SMERA'),
(31, 'APR'),
(32, 'KV'),
(33, 'RCP'),
(34, 'RM'),
(35, 'CD'),
(36, 'TM');

-- --------------------------------------------------------

--
-- Table structure for table `temp_table_elective`
--

CREATE TABLE `temp_table_elective` (
  `course_name` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `course_type` varchar(1) NOT NULL,
  `course_hours` int NOT NULL,
  `course_teacher` varchar(5) NOT NULL,
  `course_teacher_id` int NOT NULL,
  `class` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `temp_table_lab`
--

CREATE TABLE `temp_table_lab` (
  `course_name` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `course_type` varchar(1) NOT NULL,
  `course_hours` int NOT NULL,
  `t_one` varchar(5) NOT NULL,
  `t_one_id` int NOT NULL,
  `t_two` varchar(5) NOT NULL,
  `t_two_id` int NOT NULL,
  `t_three` varchar(5) NOT NULL,
  `t_three_id` int NOT NULL,
  `t_four` varchar(5) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `t_four_id` int NOT NULL,
  `class` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `temp_table_labelective`
--

CREATE TABLE `temp_table_labelective` (
  `course_name` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `course_type` varchar(1) NOT NULL,
  `course_hours` int NOT NULL,
  `course_teacher` varchar(5) NOT NULL,
  `course_teacher_id` int NOT NULL,
  `class` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `temp_table_theory`
--

CREATE TABLE `temp_table_theory` (
  `course_name` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `course_type` varchar(1) NOT NULL,
  `course_hours` int NOT NULL,
  `course_teacher` varchar(5) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `course_teacher_id` int NOT NULL,
  `class` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`course_code`);

--
-- Indexes for table `teachers`
--
ALTER TABLE `teachers`
  ADD PRIMARY KEY (`teacher_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
