<html>
    <!DOCTYPE html>
    <html>
    <head>
        <title>Teacher Timetable</title>
        <link rel="stylesheet" type="text/css" href="css/s.css">
        <link href="css/s.css?v=<?php echo time(); ?>" rel="stylesheet" type="text/css" />
    </head>
    <body>
        <div class="img">
            <img src="img/5.png"height="120%" width="100%">
        </div>
        <div class="h1">
        <h1><center>Teacher Timetable</center></h1>
    </div>
    <div><div class="navbar">
        <img src="img/logo.png" class="logo">
         <ul>
            <li><a href="new.php">AUTOMATE</a></li>
            <li><a href="teacher.php">TEACHER TABLE</a></li>
            <li><a href="class.php">CLASS TABLE</a></li>
            <li><a href="aboutus.html"> ABOUT US</a></li> 
            <li><a href="login.html">login</a></li>   
         </ul>
    </div></div> 

    <div class="automate"><h1>SCHEDULE CLASSES USING YOUR CUSTOMISED TIME TABLE </h1></div>

        <div class="form">
        <form action="text.php" method="post">
            <label for="select-teacher">Select Teacher:</label>
            <select id="select-teacher">
                <option value="">--Select a teacher--</option>
                <option value="teacher1">Teacher 1</option>
                <option value="teacher2">Teacher 2</option>
                <option value="teacher3">Teacher 3</option>
                <option value="teacher4">Teacher 4</option>
                <option value="teacher5">Teacher 5</option>
                <option value="teacher6">Teacher 6</option>
                <option value="teacher7">Teacher 7</option>

        
            </select>
           
            </select>
            <br>
            <label for="radio-schedule">Select Schedule Type:</label>
            <br>
            <input type="radio" id="radio-regular" name="schedule" value="regular">
            <label for="radio-regular">Regular Schedule</label>
            <br>
            <input type="radio" id="radio-revised" name="schedule" value="revised">
            <label for="radio-revised">Revised Schedule</label>
            <br><br>
            <button  value="Show Timetable" onclick="showTimetable()" style="background-color:gray;margin-left:1cm;color:white;text-align:center;font-family: 'Times New Roman', Times, serif;font-size:20px;padding:0.1cm 2cm;">SHOW TIMETABLE</button>

            <!-- <input type="button" value="Show Timetable" onclick="showTimetable()"> -->
        </form>
        </div>
        <br><br>


        
        <footer id="main-footer">
  <div id="footer-content">
    <div id="about">
      <h3>About Us</h3>
      <p>TIMESHEET is a leading provider of cutting-edge scheduling software for schools and universities, offering customized solutions that optimize resource utilization, increase efficiency, and improve student outcomes.</p>
    </div>
    <nav id="footer-links">
      <h3>Useful Links</h3>
      <ul>
        <li><a href="new.php">Automate</a></li>
        <li><a href="teacher.php">Teacher Table</a></li>
        <li><a href="class.php">Class Table</a></li>
        <li><a href="#">About Us</a></li>
      </ul>
    </nav>
    <div id="contact">
      <h3>Contact Us</h3>
      <p>123 Main St, Anytown, India</p>
      <p>Email: automatetimesheet@gmail.com</p>
      <p>Phone: 555-555-5555</p>
    </div>
  </div>
  <div id="footer-bottom">
    <p>© 2023 Example Company. All rights reserved.</p>
  </div>
</footer>


        <script src="script.js"></script>
    </body>
    </html>
    