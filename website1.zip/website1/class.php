<?php

?>
<!DOCTYPE html>
<html>
<head>
    <title>Teacher Timetable</title>
    <style>
        .box {
            margin: 0 auto;
            text-align: center;
        }
        .h1 {
            width: 100%;
            position: absolute;
            top: 59%;
            transform: translate(4%);
        }
    </style>
     <link rel="stylesheet" href="css/m.css">
    <link href="css/m.css?v=<?php echo time(); ?>" rel="stylesheet" type="text/css"/>
</head>

<body>


    <div class="img">
        <img src="img/4.png" height="100%" width="100%">
    </div>
    
    <div>
        <div class="navbar">
            <img src="img/logo.png" class="logo">
            <ul>
                <li><a href="new.php">AUTOMATE</a></li>
                <li><a href="teacher.php">TEACHER TABLE</a></li>
                <li><a href="class.php">CLASS TABLE</a></li>
                <li><a href="aboutus.html">ABOUT US</a></li> 
                <li><a href="login.html">LOGIN</a></li>   
            </ul>
        </div>
    </div> 

    <div class="automate"><h1>CREATE YOUR CUSTOMISED CLASS TIME TABLE</h1></div>
    <br><br>

    <div class="automate1">
    <form action ="index1a.php" method = "post">
    <div class="box">
        
        <label for="radio-regular">Select Course:</label>
        <br>
        <input type="radio" id="radio-regular" name="class" value="BCA">
        <label for="radio-revised">BCA</label><br>
        <input type="radio" id="radio-regular" name="class" value="BCA">
        <label for="radio-revised">CME</label><br>
        <input type="radio" id="radio-regular" name="class" value="BCA">
        <label for="radio-revised">BSC</label>
        <br><br>
        
        <button style="background-color:gray;color:white;text-align:center;font-family: 'Times New Roman', Times, serif;font-size:20px;padding:0.1cm 2cm;">CLICK HERE</button>

        </form>
    </div>
    </div>



    <footer id="main-footer">
  <div id="footer-content">
    <div id="about">
      <h3>About Us</h3>
      <p>TIMESHEET is a leading provider of cutting-edge scheduling software for schools and universities, offering customized solutions that optimize resource utilization, increase efficiency, and improve student outcomes.</p>
    </div>
    <nav id="footer-links">
      <h3>Useful Links</h3>
      <ul>
        <li><a href="new.php">Automate</a></li>
        <li><a href="teacher.php">Teacher Table</a></li>
        <li><a href="class.php">Class Table</a></li>
        <li><a href="#">About Us</a></li>
      </ul>
    </nav>
    <div id="contact">
      <h3>Contact Us</h3>
      <p>123 Main St, Anytown, India</p>
      <p>Email: automatetimesheet@gmail.com</p>
      <p>Phone: 555-555-5555</p>
    </div>
  </div>
  <div id="footer-bottom">
    <p>© 2023 Example Company. All rights reserved.</p>
  </div>
</footer>
</body>
</html>
