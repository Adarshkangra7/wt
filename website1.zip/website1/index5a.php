<?php

    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "timetable";

    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    if ($_SERVER["REQUEST_METHOD"] == "POST") {

        $sql = "SELECT course_name, course_type, course_hours FROM courses WHERE course_code LIKE 'BCA5%'";
        $result = $conn->query($sql);

        if($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                if ($row["course_type"] == "C") {
                    $sql2 = "select teacher_id from teachers where teacher_name like '" . $_POST[str_replace(" ", "_", $row["course_name"])] . "';";
                    $result2 = $conn->query($sql2);
                    while ($row2 = $result2->fetch_assoc()) {
                        $insert_query = "insert into temp_table_theory values ('" . $row["course_name"] . "','" . $row["course_type"] . "'," . $row["course_hours"] . ",'" . $_POST[str_replace(" ", "_", $row["course_name"])] . "'," . $row2["teacher_id"] . ", 'bcaa5');";
                        $conn->query($insert_query);
                        $conn->commit();

                    }
                    
                } else {
                    $temp_array = [];
                    $temp_array[0] = $row["course_name"];
                    $temp_array[1] = $row["course_type"];
                    $temp_array[2] = $row["course_hours"];
                    $index = 3; // Initialize index variable outside of the loop
                    for ($i = 1; $i <= 4; $i++) {
                        $post_key = $i . str_replace(" ", "_", $row["course_name"]);
                        $sql2 = "select teacher_id from teachers where teacher_name like '" . $_POST[$post_key] . "';";
                        $result2 = $conn->query($sql2);
                        while ($row2 = $result2->fetch_assoc()) {
                            $temp_array[$index] = $_POST[$post_key];
                            $temp_array[$index + 1] = $row2["teacher_id"];
                            $index += 2; // Increment index by 2 after each successful assignment
                        }
                    }

                    if ($temp_array[10] == 0) {
                        $temp_array[9] = $temp_array[3];
                        $temp_array[10] = $temp_array[4];
                    }

                    $insert_query = "insert into temp_table_lab values('" . $temp_array[0] . "','" .$temp_array[1]  . "'," . $temp_array[2] . ",'" . $temp_array[3] . "'," . $temp_array[4] . ",'" . $temp_array[5] . "'," . $temp_array[6] . ",'" . $temp_array[7] . "'," . $temp_array[8] . ",'" . $temp_array[9] . "'," . $temp_array[10] . ", 'bcaa5');";
                    $conn->query($insert_query);
                    $conn->commit();
                
                }
            }
        }
        header("Location: index5b.php");
        exit();
    }
    $conn->close();

?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>INPUT FORM</title>
    <link rel="stylesheet" href="styles/style.css">

    
</head>

<body>
    <h1>ENTER DETAILS FOR THE CLASS 5BCA - A</h1>
    <h4>Leave dropdown list empty (first option) if no teacher is there</h4>
    <link rel="stylesheet" href="style3.css">


    <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
        <?php

        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "timetable";

        $conn = new mysqli($servername, $username, $password, $dbname);
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        $sql = "SELECT * FROM courses WHERE course_code LIKE 'BCA5%'";
        $result = $conn->query($sql);

        if($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<label for='" . $row["course_name"] . "'>" . $row["course_name"] . ": </label>";

                if ($row['course_type'] == "L") {
                    echo "<br>";
                    for ($i = 1; $i <= 4; $i++) {
                        echo "<select name='" . $i . $row["course_name"] . "' id='" . $i . $row["course_name"] . "'>";

                        $sql2 = "SELECT * FROM teachers";
                        $result2 = $conn->query($sql2);

                        while ($row2 = $result2->fetch_assoc()) {
                            echo "<option value='" . $row2["teacher_name"] . "'>" . $row2["teacher_name"] . "</option>";
                        }
                        echo "</select>"; 
                        
                    }
                    echo "<br>";
                } else {
                    echo "<select name='" . $row["course_name"] . "' id='" . $row["course_name"] . "'>";
                    $sql2 = "SELECT * FROM teachers";
                    $result2 = $conn->query($sql2);

                    while ($row2 = $result2->fetch_assoc()) {
                        echo "<option value='" . $row2["teacher_name"] . "'>" . $row2["teacher_name"] . "</option>";
                    }
                    echo "</select><br><br>";       
                 
                }             
            }
        } else {
            echo "0 results";

            }
            $conn->close();
        ?>
        <input type="submit" value="Submit" id="btn">
    </form>
    
</body>
</html>