<!DOCTYPE html>
<html>
<head>
	<title>Teacher and Class Form</title>
</head>
<body>

	<h1>Teacher and Class Form</h1>

	<?php
	
	$teachers = array("Mr.KNS", "Ms.KAVITA", "Mr.TTOBY");
	$classes = array("OS", "MATH", "English", "DATABASE");
	$subject_codes = array("MATH101", "OS101", "ENG101", "DATABASE101");

	
	if ($_SERVER['REQUEST_METHOD'] == 'POST') {
		$name = $_POST['name'];
		$teacher = $_POST['teacher'];
		$class = $_POST['class'];
		$subject_code = $_POST['subject_code'];

		
		echo "<p>You selected $teacher as your teacher, $class as your class, and $subject_code as your subject code.</p>";
	}
	?>

	<form method="post" action="">
		<label for="name">Enter your name:</label>
		<input type="text" name="name" id="name">

		<br><br>

		<label for="teacher">Select your teacher:</label>
		<select name="teacher" id="teacher">
			<?php
			
			foreach ($teachers as $teacher) {
				echo "<option value=\"$teacher\">$teacher</option>";
			}
			?>
		</select>

		<br><br>

		<label for="class">Select your class:</label>
		<select name="class" id="class">
			<?php
			
			foreach ($classes as $class) {
				echo "<option value=\"$class\">$class</option>";
			}
			?>
		</select>

		<br><br>

		<label for="subject_code">Select your subject code:</label>
		<select name="subject_code" id="subject_code">
			<?php
			
			foreach ($subject_codes as $subject_code) {
				echo "<option value=\"$subject_code\">$subject_code</option>";
			}
			?>
		</select>

		<br><br>

		<input type="submit" value="Submit">
	</form>

</body>
</html>
