<html>
    <head>
        <title>Timesheet offical website </title>
        <link rel="stylesheet" href="css/r.css">
        <style>
            .flex-container {
              display: flex;
            }
             </style>
    </head>

    <body>
        <div class="flex-container">
            <div><div class="img">
           
                <center><img src="img/Untitled.jpeg" height=108% width=105%></center>
            </div></div>
            <div><div class="navbar">
                <img src="img/logo trans.png" class="logo">
                 <ul>
                    <li><a href="new.php">AUTOMATE</a></li>
                    <li><a href="teacher.php">TEACHER TABLE</a></li>
                    <li><a href="class.php">CLASS TABLE</a></li>
                    <li><a href="about.html"> ABOUT US</a></li> 
                    <li><a href="login.html">login</a></li>   
                 </ul>
            </div></div> 
          </div>
           
        <div class="content">
            <h1>AUTOMATE YOUR TIME TABLE </h1>
            <P>You can use tables to create a schedule and customize table layout and style</P>
            <div>
                <button type="button" ><span></span>CREATE</button>
                <button type="button"><span></span>SELECT DESIGN</button>
            </div>
        </div>

        <div >
           <img src="img/IMG_2967-2.jpg" height=108% width=105%> 
            <h1 id="au">Automate For teachers</h1>
            <p id="teach">Make teachers timetable <a href=''> now </a></p>
            
        </div>
        <div>
            <img src="img/empty.jpg" height="108%" width="105%">
            <div class="hello">
                <h1>Automate for student </h1>
                <button type="button" ><span></span>CREATE</button>
                <button type="button"><span></span>SELECT DESIGN</button>
            </div>
        </div>

   </body>
    </html>

    
     