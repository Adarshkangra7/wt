<html>
    <!DOCTYPE html>
    <html>
    <head>
        <title>Teacher Timetable</title>
        <link rel="stylesheet" type="text/css" href="css/s.css">
    </head>
    <body>
        <div class="img">
            <img src="img/wallpaperflare.com_wallpaper-6-2.jpg"height="108%" width="108%">
        </div>
        <div class="h1">
        <h1><center>Teacher Timetable</center></h1>
    </div>
    <div><div class="navbar">
        <img src="img/logo trans.png" class="logo">
         <ul>
            <li><a href="new.php">AUTOMATE</a></li>
            <li><a href="teacher.php">TEACHER TABLE</a></li>
            <li><a href="class.php">CLASS TABLE</a></li>
            <li><a href="aboutus.html"> ABOUT US</a></li> 
            <li><a href="login.html">login</a></li>   
         </ul>
    </div></div> 
        <div class="form">
        <form action="index1a.php" method="post">
            <label for="select-teacher">Select Teacher:</label>
            <select id="select-teacher">
                <option value="">--Select a teacher--</option>
                <option value="teacher1">Teacher 1</option>
                <option value="teacher2">Teacher 2</option>
                <option value="teacher3">Teacher 3</option>
                <option value="teacher4">Teacher 4</option>
                <option value="teacher5">Teacher 5</option>
                <option value="teacher6">Teacher 6</option>
                <option value="teacher7">Teacher 7</option>

        
            </select>
            <br><br>
            <label for="select-day">Select Day:</label>
            <select id="select-day">
                <option value="">--Select a day--</option>
                <option value="monday">Monday</option>
                <option value="tuesday">Tuesday</option>
                <option value="wednesday">Wednesday</option>
                <option value="thursday">Thursday</option>
                <option value="friday">Friday</option>
                <option value="Saturday">saturday</option>
            </select>
            <br><br>
            <label for="radio-schedule">Select Schedule Type:</label>
            <br>
            <input type="radio" id="radio-regular" name="schedule" value="regular">
            <label for="radio-regular">Regular Schedule</label>
            <br>
            <input type="radio" id="radio-revised" name="schedule" value="revised">
            <label for="radio-revised">Revised Schedule</label>
            <br><br>
            <input type="button" value="Show Timetable" onclick="showTimetable()">
        </form>
        </div>
        <br><br>
        <script src="script.js"></script>
    </body>
    </html>
    