<?php

?>
<!DOCTYPE html>
<html>
<head>
    <title>Teacher Timetable</title>
    <style>
        .box {
            margin: 0 auto;
            text-align: center;
        }
        .h1 {
            width: 100%;
            position: absolute;
            top: 59%;
            transform: translate(4%);
        }
    </style>
     <link rel="stylesheet" href="css/m.css">
    <link href="css/m.css?v=<?php echo time(); ?>" rel="stylesheet" type="text/css"/>
</head>

<body>


    <div class="img">
        <img src="img/wallpaperflare.com_wallpaper-6-2.jpg" height="108%" width="108%">
    </div>
    <div class="h1">
        <h1><center>Teacher Timetable</center></h1>
    </div>
    <div>
        <div class="navbar">
            <img src="img/logo trans.png" class="logo">
            <ul>
                <li><a href="new.php">AUTOMATE</a></li>
                <li><a href="teacher.php">TEACHER TABLE</a></li>
                <li><a href="class.php">CLASS TABLE</a></li>
                <li><a href="aboutus.html">ABOUT US</a></li> 
                <li><a href="login.html">LOGIN</a></li>   
            </ul>
        </div>
    </div> 
    <br><br>
    <form action ="index1a.php" method = "post">
    <div class="box">
        <label for="radio-schedule">Select Schedule Type:</label>
        <br>
        <label for="radio-regular">Select Class:</label>
        <input type="radio" id="radio-regular" name="class" value="BCA">
        <label for="radio-revised">BCA</label>
        <br><br>
        <input type="submit" value="SUBMIT">
        </form>
    </div>
</body>
</html>
